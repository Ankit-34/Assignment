const links = [
    {
      image:
        "https://cmexpertise.com/wp-content/uploads/2022/05/banner-6.svg",
        title : "Our Moto Is To Serve You..."
    },
    {
      image:
        "https://taximandu.com/wp-content/uploads/2021/05/3.png",
        title : "Our Moto Is To Serve You..."
      },
      {
        image:
        "https://img.freepik.com/free-vector/taxi-app-concept-illustration_23-2148481837.jpg",
        title : "Our Moto Is To Serve You..."
      },
      {
        // https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2v4ri1soFCjp9xHdBkOKsN9cxnpyAVsEEQHb_MO-RfcM7eWLaoK8fbtXfKrk-femN7B8&usqp=CAU
        image:
        "https://img.freepik.com/free-vector/man-tourist-with-suitcase-taxi-car_24877-53453.jpg",
        title : "Our Moto Is To Serve You..."
      },
    ];
  
  export default links;